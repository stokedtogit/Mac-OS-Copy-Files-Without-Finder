#!/usr/bin/env bash
# =============================================================
#  copy_photos_gui.sh — Core copy logic driven by GUI args
#  Usage: copy_photos_gui.sh <source> <destination> <days> <filecount>
# =============================================================

set -uo pipefail

SRC="${1:-}"
DST="${2:-}"
DAYS="${3:-1}"
FILECOUNT="${4:-}"

# ── Validate inputs ───────────────────────────────────────────
if [[ -z "$SRC" || -z "$DST" ]]; then
  osascript -e 'display alert "Photo Copy Error" message "Source or destination folder was not provided." as critical'
  exit 1
fi

SRC="${SRC%/}"
DST="${DST%/}"

if [[ ! -d "$SRC" ]]; then
  osascript -e "display alert \"Photo Copy Error\" message \"Source folder not found:\n$SRC\" as critical"
  exit 1
fi

if [[ ! -d "$DST" ]]; then
  mkdir -p "$DST" || {
    osascript -e "display alert \"Photo Copy Error\" message \"Could not create destination folder:\n$DST\" as critical"
    exit 1
  }
fi

[[ "$DAYS" =~ ^[0-9]+$ ]] || DAYS=1

# ── Show in-progress notification immediately ─────────────────
# This fires as soon as the copy starts, before any files are touched
PROGRESS_MSG="Copying ${FILECOUNT} file(s) in progress.\n\nPlease do not quit this app until the copy is complete."
osascript -e "display notification \"Copying ${FILECOUNT} file(s) — please wait…\" with title \"Photo Copy In Progress\""
osascript -e "display dialog \"${PROGRESS_MSG}\" with title \"Photo Copy In Progress\" buttons {} giving up after 1" &>/dev/null &
DIALOG_PID=$!

# ── Scan for files ────────────────────────────────────────────
CUTOFF=$(( DAYS + 1 ))
FILES=()
while IFS= read -r -d '' f; do
  filename="$(basename "$f")"
  [[ "$filename" == *.* ]] || continue
  FILES+=("$f")
done < <(find "$SRC" -type f -mtime "-${CUTOFF}" -print0 2>/dev/null | sort -z)

TOTAL=${#FILES[@]}

if [[ $TOTAL -eq 0 ]]; then
  kill "$DIALOG_PID" 2>/dev/null || true
  osascript -e "display alert \"No Files Found\" message \"No files were found in the last $DAYS day(s).\nTry increasing the number of days.\" as warning"
  exit 0
fi

# ── Copy files ────────────────────────────────────────────────
COPIED=0
SKIPPED=0
ERRORS=0

for src_file in "${FILES[@]}"; do
  filename="$(basename "$src_file")"
  dst_file="${DST}/${filename}"

  if [[ -e "$dst_file" ]]; then
    src_size=$(stat -f%z "$src_file")
    dst_size=$(stat -f%z "$dst_file")
    if [[ "$src_size" == "$dst_size" ]]; then
      (( SKIPPED++ )) || true
      continue
    fi
  fi

  if rsync -a --no-whole-file "$src_file" "$dst_file" 2>/dev/null; then
    (( COPIED++ )) || true
  else
    (( ERRORS++ )) || true
  fi
done

# ── Dismiss in-progress dialog ────────────────────────────────
kill "$DIALOG_PID" 2>/dev/null || true

# ── Completion alert ──────────────────────────────────────────
MSG="Copied: $COPIED  |  Skipped (duplicates): $SKIPPED  |  Errors: $ERRORS"

if [[ $ERRORS -gt 0 ]]; then
  osascript -e "display alert \"Photo Copy Complete\" message \"$MSG\" as warning"
else
  osascript -e "display notification \"$MSG\" with title \"Photo Copy Complete\" subtitle \"$COPIED file(s) copied to $(basename "$DST")\""
  osascript -e "display alert \"Photo Copy Complete\" message \"$MSG\""
fi
